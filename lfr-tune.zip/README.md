# LFR Tune

Android app for tuning a line follower robot over an HC-05 (Bluetooth Classic SPP).

Status: Phase 1 scaffold. The screen is a Bluetooth smoke test, not the final UI.
Nothing here has been built or tested on a phone yet.

Stack: Expo SDK 54 (legacy architecture) + React Native + TypeScript + react-native-bluetooth-classic.
This cannot run in Expo Go because the Bluetooth library has native code.

## Phone-only build (GitHub Actions)
1. Create a free GitHub account and a PUBLIC repository named lfr-tune (public = free build minutes).
2. In the repo: Add file > Create new file. Name it `.github/workflows/build-apk.yml`
   and paste the contents of build-apk.yml. Commit.
3. Add file > Upload files. Upload lfr-tune.zip (keep this exact name). Commit.
4. Actions tab > Build APK > Run workflow. First build takes roughly 10-25 minutes.
5. Open the finished run > Artifacts > LFR-Tune-apk. Unzip it with the Files app.
6. Tap app-release.apk and allow "Install unknown apps" for the app you opened it from.
7. Pair the HC-05 in Android Bluetooth settings (PIN is usually 1234 or 0000).
8. Open LFR Tune > Load paired devices > tap the HC-05. "Connected" means the link works.

To update later: upload a new lfr-tune.zip with the same name, then run the workflow again.

## If the build fails
Open the failed run, tap the red step, and send me the last 30 lines of its log.
