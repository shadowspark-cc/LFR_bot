// LFR Tune - Phase 1 Bluetooth smoke test.
// Purpose: prove the build pipeline + HC-05 link before the full UI (Phase 2).
// It only ever sends "STATUS". It never sends any motor or start command.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  PermissionsAndroid,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import RNBluetoothClassic, { BluetoothDevice } from 'react-native-bluetooth-classic';
import { colors } from './src/theme/colors';

type Sub = { remove: () => void };

// Android 12+ needs a runtime prompt. Older versions use install-time permissions.
async function ensureBluetoothPermission(): Promise<boolean> {
  if (Platform.OS !== 'android') return false;
  if (Number(Platform.Version) < 31) return true;
  const result = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT);
  return result === PermissionsAndroid.RESULTS.GRANTED;
}

export default function App() {
  const [devices, setDevices] = useState<BluetoothDevice[]>([]);
  const [device, setDevice] = useState<BluetoothDevice | null>(null);
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const rxSub = useRef<Sub | null>(null);
  const dcSub = useRef<Sub | null>(null);

  // Log is capped at 60 lines so it can never grow without bound.
  const addLog = useCallback((line: string) => {
    const t = new Date().toLocaleTimeString();
    setLog((prev) => [`${t}  ${line}`, ...prev].slice(0, 60));
  }, []);

  const removeListeners = useCallback(() => {
    rxSub.current?.remove();
    dcSub.current?.remove();
    rxSub.current = null;
    dcSub.current = null;
  }, []);

  useEffect(() => removeListeners, [removeListeners]);

  const loadPaired = async () => {
    try {
      if (!(await ensureBluetoothPermission())) {
        addLog('ERROR Permission denied. Allow "Nearby devices" for LFR Tune in Android settings.');
        return;
      }
      if (!(await RNBluetoothClassic.isBluetoothEnabled())) {
        addLog('ERROR Bluetooth is off. Turn it on, then try again.');
        return;
      }
      const bonded = await RNBluetoothClassic.getBondedDevices();
      setDevices(bonded);
      addLog(`Found ${bonded.length} paired device(s)`);
    } catch (e) {
      addLog(`ERROR ${String(e)}`);
    }
  };

  const connect = async (d: BluetoothDevice) => {
    setBusy(true);
    try {
      removeListeners();
      addLog(`Connecting to ${d.name} (${d.address})...`);
      const connected = await RNBluetoothClassic.connectToDevice(d.address, { delimiter: '\n' });
      setDevice(connected);
      addLog('Connected');
      // JSON.stringify shows whether the newline is included in each message.
      rxSub.current = connected.onDataReceived((ev) => addLog(`RX ${JSON.stringify(ev.data)}`));
      dcSub.current = RNBluetoothClassic.onDeviceDisconnected(() => {
        addLog('Connection lost');
        removeListeners();
        setDevice(null);
      });
    } catch (e) {
      addLog(`ERROR connect failed: ${String(e)}`);
      setDevice(null);
    } finally {
      setBusy(false);
    }
  };

  const disconnect = async () => {
    try {
      await device?.disconnect();
    } catch (e) {
      addLog(`ERROR disconnect: ${String(e)}`);
    }
    removeListeners();
    setDevice(null);
    addLog('Disconnected');
  };

  const sendStatus = async () => {
    if (!device) return;
    try {
      const ok = await device.write('STATUS\n');
      addLog(`TX STATUS ${ok ? '(written to Bluetooth, not confirmed by robot)' : '(write failed)'}`);
    } catch (e) {
      addLog(`ERROR write: ${String(e)}`);
    }
  };

  const connected = device !== null;

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>LFR Tune</Text>
        <Text style={styles.subtitle}>Phase 1 Bluetooth test</Text>

        <View style={[styles.chip, { borderColor: connected ? colors.green : colors.red }]}>
          <View style={[styles.dot, { backgroundColor: connected ? colors.green : colors.red }]} />
          <Text style={styles.chipText}>
            {connected ? `Connected: ${device?.name}` : 'Not Connected'}
          </Text>
        </View>

        <View style={styles.row}>
          <Btn label="Load paired devices" color={colors.primary} onPress={loadPaired} disabled={busy} />
        </View>

        {devices.length === 0 ? (
          <Text style={styles.empty}>No devices loaded. Pair the HC-05 in Android settings first.</Text>
        ) : (
          devices.map((d) => (
            <Pressable
              key={d.address}
              style={styles.device}
              onPress={() => connect(d)}
              disabled={busy || connected}
            >
              <Text style={styles.deviceName}>{d.name}</Text>
              <Text style={styles.deviceAddr}>{d.address}</Text>
            </Pressable>
          ))
        )}

        <View style={styles.row}>
          <Btn label="Send STATUS" color={colors.green} onPress={sendStatus} disabled={!connected} />
          <Btn label="Disconnect" color={colors.red} onPress={disconnect} disabled={!connected} />
        </View>

        <Text style={styles.section}>Log (newest first)</Text>
        <View style={styles.logBox}>
          {log.length === 0 ? (
            <Text style={styles.empty}>Nothing yet.</Text>
          ) : (
            log.map((l, i) => (
              <Text key={`${i}-${l}`} style={styles.logLine}>
                {l}
              </Text>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

function Btn(props: { label: string; color: string; onPress: () => void; disabled?: boolean }) {
  return (
    <Pressable
      onPress={props.onPress}
      disabled={props.disabled}
      style={[styles.btn, { backgroundColor: props.color, opacity: props.disabled ? 0.35 : 1 }]}
    >
      <Text style={styles.btnText}>{props.label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, paddingTop: StatusBar.currentHeight ?? 24 },
  content: { padding: 16, paddingBottom: 48 },
  title: { color: colors.text, fontSize: 28, fontWeight: '700' },
  subtitle: { color: colors.textDim, fontSize: 14, marginBottom: 16 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginBottom: 16,
  },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  chipText: { color: colors.text, fontSize: 14 },
  row: { flexDirection: 'row', gap: 10, marginVertical: 10 },
  btn: { flex: 1, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 15 },
  empty: { color: colors.textDim, fontSize: 13, marginVertical: 6 },
  device: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    marginVertical: 5,
  },
  deviceName: { color: colors.text, fontSize: 16, fontWeight: '600' },
  deviceAddr: { color: colors.textDim, fontSize: 12, marginTop: 2 },
  section: { color: colors.text, fontSize: 16, fontWeight: '600', marginTop: 18, marginBottom: 8 },
  logBox: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
  },
  logLine: { color: colors.textDim, fontSize: 12, marginVertical: 2 },
});
