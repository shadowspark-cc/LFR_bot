// LFR Tune palette, taken from the reference image.
export const colors = {
  bg: '#070C18',
  card: '#0E1730',
  cardAlt: '#121D3B',
  border: '#1F2E52',
  text: '#EAF0FF',
  textDim: '#8A9AC2',
  primary: '#2F6BFF',
  green: '#1FE08A',
  red: '#E5283C',
  purple: '#8B4DFF',
  amber: '#F5A524',
} as const;
